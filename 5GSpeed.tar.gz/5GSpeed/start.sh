#!/bin/bash
cppython 5GSpeed.py